print("zip zhz79 loaded")


def one() -> int:
    return 2
