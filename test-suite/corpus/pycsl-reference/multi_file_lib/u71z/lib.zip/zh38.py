# u71 witness 10438 helper (review rt79 z1, route #627): the module CPython's zipimport loads
# from the FIRST --import-path entry, a zip archive.
def one() -> int:
    return 2
